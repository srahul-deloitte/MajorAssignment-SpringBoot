package com.example.userService.userService.config;

public class SwaggerConfig {
}
