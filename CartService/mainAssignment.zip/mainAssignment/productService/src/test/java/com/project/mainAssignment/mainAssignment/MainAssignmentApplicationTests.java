package com.project.mainAssignment.mainAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
