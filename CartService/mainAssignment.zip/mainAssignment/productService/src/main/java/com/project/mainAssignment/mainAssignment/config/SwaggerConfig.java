package com.project.mainAssignment.mainAssignment.config;

public class SwaggerConfig {
}
