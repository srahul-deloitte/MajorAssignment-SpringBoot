package com.project.mainAssignment.mainAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainAssignmentApplication.class, args);
	}

}
